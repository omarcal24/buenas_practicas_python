ope package
===========

Submodules
----------

ope.operaciones module
----------------------

.. automodule:: ope.operaciones
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: ope
   :members:
   :undoc-members:
   :show-inheritance:
