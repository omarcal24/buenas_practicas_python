operaciones module
==================

.. automodule:: operaciones
   :members:
   :undoc-members:
   :show-inheritance:
