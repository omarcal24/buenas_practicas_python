import operaciones

if __name__ == "__main__":
    m = operaciones.operacionesMatematicas(5, 8)
    print(m.suma())
